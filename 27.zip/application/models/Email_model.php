<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email_model extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}

	function password_reset_email($new_password = '', $pass_veri_code = '' , $email = '')
	{
		$query = $this->db->get_where('users' , array('email' => $email));
		$first_name = $this->db->get_where('users' , array('email' => $email))->row()->first_name;
		$system_name = $this->db->get_where('settings', array('key' => 'system_name'))->row()->value;
		$redirect_url = site_url('login/verify_password_request/'.$pass_veri_code);
		if($query->num_rows() > 0)
		{

			$email_msg	=	<<<HEREDOC1
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title></title>
    <style type="text/css" rel="stylesheet" media="all">
    /* Base ------------------------------ */

    @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
    body {
      width: 100% !important;
      height: 100%;
      margin: 0;
      -webkit-text-size-adjust: none;
    }

    a {
      color: #3869D4 !important;
    }

    a img {
      border: none;
    }

    td {
      word-break: break-word;
    }

    .preheader {
      display: none !important;
      visibility: hidden;
      mso-hide: all;
      font-size: 1px;
      line-height: 1px;
      max-height: 0;
      max-width: 0;
      opacity: 0;
      overflow: hidden;
    }
    /* Type ------------------------------ */

    body,
    td,
    th {
      font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
    }

    h1 {
      margin-top: 0;
      color: #333333;
      font-size: 22px;
      font-weight: bold;
      text-align: left;
    }

    h2 {
      margin-top: 0;
      color: #333333;
      font-size: 16px;
      font-weight: bold;
      text-align: left;
    }

    h3 {
      margin-top: 0;
      color: #333333;
      font-size: 14px;
      font-weight: bold;
      text-align: left;
    }

    td,
    th {
      font-size: 16px;
    }

    p,
    ul,
    ol,
    blockquote {
      margin: .4em 0 1.1875em;
      font-size: 16px;
      line-height: 1.625;
    }

	hr {
    border-top: 1px solid #fff;
    }

    p.sub {
      font-size: 13px;
    }
    /* Utilities ------------------------------ */

    .align-right {
      text-align: right;
    }

    .align-left {
      text-align: left;
    }

    .align-center {
      text-align: center;
    }
    /* Buttons ------------------------------ */

    .button {
      background-color: #3869D4;
      border-top: 10px solid #3869D4;
      border-right: 18px solid #3869D4;
      border-bottom: 10px solid #3869D4;
      border-left: 18px solid #3869D4;
      display: inline-block;
      color: #FFF;
      text-decoration: none;
      border-radius: 3px;
      box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
      -webkit-text-size-adjust: none;
      box-sizing: border-box;
    }

    .button--green {
      background-color: #22BC66;
      border-top: 10px solid #22BC66;
      border-right: 18px solid #22BC66;
      border-bottom: 10px solid #22BC66;
      border-left: 18px solid #22BC66;
    }

    .button--red {
      background-color: #FF6136;
      border-top: 10px solid #FF6136;
      border-right: 18px solid #FF6136;
      border-bottom: 10px solid #FF6136;
      border-left: 18px solid #FF6136;
    }

    @media only screen and (max-width: 500px) {
      .button {
        width: 100% !important;
        text-align: center !important;
      }
    }
    /* Attribute list ------------------------------ */

    .attributes {
      margin: 0 0 21px;
    }

    .attributes_content {
      background-color: #F4F4F7;
      padding: 16px;
    }

    .attributes_item {
      padding: 0;
    }
    /* Related Items ------------------------------ */

    .related {
      width: 100%;
      margin: 0;
      padding: 25px 0 0 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
    }

    .related_item {
      padding: 10px 0;
      color: #CBCCCF;
      font-size: 15px;
      line-height: 18px;
    }

    .related_item-title {
      display: block;
      margin: .5em 0 0;
    }

    .related_item-thumb {
      display: block;
      padding-bottom: 10px;
    }

    .related_heading {
      border-top: 1px solid #CBCCCF;
      text-align: center;
      padding: 25px 0 10px;
    }
    /* Discount Code ------------------------------ */

    .discount {
      width: 100%;
      margin: 0;
      padding: 24px;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
      background-color: #F4F4F7;
      border: 2px dashed #CBCCCF;
    }

    .discount_heading {
      text-align: center;
    }

    .discount_body {
      text-align: center;
      font-size: 15px;
    }
    /* Social Icons ------------------------------ */

    .social {
      width: auto;
    }

    .social td {
      padding: 0;
      width: auto;
    }

    .social_icon {
      height: 20px;
      margin: 0 8px 10px 8px;
      padding: 0;
    }
    /* Data table ------------------------------ */

    .purchase {
      width: 100%;
      margin: 0;
      padding: 35px 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
    }

    .purchase_content {
      width: 100%;
      margin: 0;
      padding: 25px 0 0 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
    }

    .purchase_item {
      padding: 10px 0;
      color: #51545E;
      font-size: 15px;
      line-height: 18px;
    }

    .purchase_heading {
      padding-bottom: 8px;
      border-bottom: 1px solid #EAEAEC;
    }

    .purchase_heading p {
      margin: 0;
      color: #85878E;
      font-size: 12px;
    }

    .purchase_footer {
      padding-top: 15px;
      border-top: 1px solid #EAEAEC;
    }

    .purchase_total {
      margin: 0;
      text-align: right;
      font-weight: bold;
      color: #333333;
    }

    .purchase_total--label {
      padding: 0 15px 0 0;
    }

    body {
      background-color: #F2F4F6;
      color: #51545E;
    }

    p {
      color: #51545E;
    }

    .email-wrapper {
      width: 100%;
      margin: 0;
      padding: 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
      background-color: #F2F4F6;
    }

    .email-content {
      width: 100%;
      margin: 0;
      padding: 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
    }
    /* Masthead ----------------------- */

    .email-masthead {
      padding: 25px 0;
      text-align: center;
    }

    .email-masthead_logo {
      width: 94px;
    }

    .email-masthead_name {
      font-size: 16px;
      font-weight: bold;
      color: #A8AAAF;
      text-decoration: none;
      text-shadow: 0 1px 0 white;
    }
    /* Body ------------------------------ */

    .email-body {
      width: 100%;
      margin: 0;
      padding: 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
    }

    .email-body_inner {
      width: 570px;
      margin: 0 auto;
      padding: 0;
      -premailer-width: 570px;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
      background-color: #FFFFFF;
    }

    .email-footer {
      width: 570px;
      margin: 0 auto;
      padding: 0;
      -premailer-width: 570px;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
      text-align: center;
    }

    .email-footer p {
      color: #A8AAAF;
    }

    .body-action {
      width: 100%;
      margin: 30px auto;
      padding: 0;
      -premailer-width: 100%;
      -premailer-cellpadding: 0;
      -premailer-cellspacing: 0;
      text-align: center;
    }

    .body-sub {
      margin-top: 25px;
      padding-top: 25px;
      border-top: 1px solid #EAEAEC;
    }

    .content-cell {
      padding: 45px;
    }
    /*Media Queries ------------------------------ */

    @media only screen and (max-width: 600px) {
      .email-body_inner,
      .email-footer {
        width: 100% !important;
      }
    }

    @media (prefers-color-scheme: dark) {
      body,
      .email-body,
      .email-body_inner,
      .email-content,
      .email-wrapper,
      .email-masthead,
      .email-footer {
        background-color: #333333 !important;
        color: #FFF !important;
      }
      p,
      ul,
      ol,
      blockquote,
      h1,
      h2,
      h3 {
        color: #FFF !important;
      }
      .attributes_content,
      .discount {
        background-color: #51545e !important;
      }
      .email-masthead_name {
        text-shadow: none !important;
      }
    }
    </style>
    <!--[if mso]>
    <style type="text/css">
      .f-fallback  {
        font-family: Arial, sans-serif;
      }
    </style>
  <![endif]-->
  </head>
  <body id="body">
    <table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
      <tr>
        <td align="center">
          <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
            <tr>
              <td class="email-masthead">
                <a href="
HEREDOC1;
$email_msg .= base_url();
$email_msg .= <<<HEREDOC2
" class="f-fallback email-masthead_name"><font color="#A8AAAF">
HEREDOC2;
$email_msg .= $system_name;
$email_msg .= <<<HEREDOC3
</font></a>
			</td>
		</tr>
		<!-- Email Body -->
		<tr>
			<td class="email-body" width="570" cellpadding="0" cellspacing="0">
				<table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
					<!-- Body content -->
					<tr>
						<td class="content-cell">
							<div class="f-fallback">
								<h1>Hi&nbsp;
HEREDOC3;
$email_msg .= $first_name;
$email_msg .= <<<HEREDOC4
,</h1>
								<p>You recently requested to reset your password for your account. Your new system generated password is <strong>
HEREDOC4;
$email_msg .= $new_password;
$email_msg .=<<<HEREDOC5
</strong>. It will work after you verify your request using the button below.</p>
								<!-- Action -->
								<table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0" role="presentation">
									<tr>
										<td align="center">
											<table width="100%" border="0" cellspacing="0" cellpadding="0" role="presentation">
												<tr>
													<td align="center">
														<a href="
HEREDOC5;
$email_msg .= $redirect_url;
$email_msg .= <<<HEREDOC6
" class="f-fallback button button--green" target="_blank"><font color="#ffffff">Verify password request</font></a>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<hr><table>
									<tr>
										<td>
											<p>Thanks,
											<br>The&nbsp;
HEREDOC6;
$email_msg .= $system_name;
$email_msg .= <<<HEREDOC7
 Team</p>
										</td>
									</tr>
								</table>
							</div>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<tr>
			<td>
				<table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
					<tr>
						<td class="content-cell" align="center">
							<p class="f-fallback sub align-center">&copy; 2020&nbsp;
HEREDOC7;
$email_msg .= $system_name;
$email_msg .= <<<HEREDOC8
. All rights reserved.</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</td>
</tr>
</table>
</body>
</html>
HEREDOC8;
			$email_sub	=	"Password Reset";
			$email_to	=	$email;
			//$this->do_email($email_msg , $email_sub , $email_to);
			$this->send_smtp_mail($email_msg , $email_sub , $email_to);
			return true;
		}
		else
		{
			return false;
		}
	}

	public function send_email_verification_mail($to = "", $verification_code = "") {
		$first_name = $this->db->get_where('users' , array('verification_code' => $verification_code))->row()->first_name;
		$system_name = $this->db->get_where('settings', array('key' => 'system_name'))->row()->value;
		$redirect_url = site_url('login/verify_email_address/'.$verification_code);
		$subject 		= "Verify Email Address";
		$email_msg	=	<<<HEREDOK1
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		<html>
		<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title></title>
		<style type="text/css" rel="stylesheet" media="all">
		/* Base ------------------------------ */

		@import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
		body {
		width: 100% !important;
		height: 100%;
		margin: 0;
		-webkit-text-size-adjust: none;
		}

		a {
		color: #3869D4 !important;
		}

		a img {
		border: none;
		}

		td {
		word-break: break-word;
		}

		.preheader {
		display: none !important;
		visibility: hidden;
		mso-hide: all;
		font-size: 1px;
		line-height: 1px;
		max-height: 0;
		max-width: 0;
		opacity: 0;
		overflow: hidden;
		}
		/* Type ------------------------------ */

		body,
		td,
		th {
		font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
		}

		h1 {
		margin-top: 0;
		color: #333333;
		font-size: 22px;
		font-weight: bold;
		text-align: left;
		}

		h2 {
		margin-top: 0;
		color: #333333;
		font-size: 16px;
		font-weight: bold;
		text-align: left;
		}

		h3 {
		margin-top: 0;
		color: #333333;
		font-size: 14px;
		font-weight: bold;
		text-align: left;
		}

		td,
		th {
		font-size: 16px;
		}

		p,
		ul,
		ol,
		blockquote {
		margin: .4em 0 1.1875em;
		font-size: 16px;
		line-height: 1.625;
		}

		hr {
		border-top: 1px solid #fff;
		}

		p.sub {
		font-size: 13px;
		}
		/* Utilities ------------------------------ */

		.align-right {
		text-align: right;
		}

		.align-left {
		text-align: left;
		}

		.align-center {
		text-align: center;
		}
		/* Buttons ------------------------------ */

		.button {
		background-color: #3869D4;
		border-top: 10px solid #3869D4;
		border-right: 18px solid #3869D4;
		border-bottom: 10px solid #3869D4;
		border-left: 18px solid #3869D4;
		display: inline-block;
		color: #FFF;
		text-decoration: none;
		border-radius: 3px;
		box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
		-webkit-text-size-adjust: none;
		box-sizing: border-box;
		}

		.button--green {
		background-color: #22BC66;
		border-top: 10px solid #22BC66;
		border-right: 18px solid #22BC66;
		border-bottom: 10px solid #22BC66;
		border-left: 18px solid #22BC66;
		}

		.button--red {
		background-color: #FF6136;
		border-top: 10px solid #FF6136;
		border-right: 18px solid #FF6136;
		border-bottom: 10px solid #FF6136;
		border-left: 18px solid #FF6136;
		}

		@media only screen and (max-width: 500px) {
		.button {
		  width: 100% !important;
		  text-align: center !important;
		}
		}
		/* Attribute list ------------------------------ */

		.attributes {
		margin: 0 0 21px;
		}

		.attributes_content {
		background-color: #F4F4F7;
		padding: 16px;
		}

		.attributes_item {
		padding: 0;
		}
		/* Related Items ------------------------------ */

		.related {
		width: 100%;
		margin: 0;
		padding: 25px 0 0 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		}

		.related_item {
		padding: 10px 0;
		color: #CBCCCF;
		font-size: 15px;
		line-height: 18px;
		}

		.related_item-title {
		display: block;
		margin: .5em 0 0;
		}

		.related_item-thumb {
		display: block;
		padding-bottom: 10px;
		}

		.related_heading {
		border-top: 1px solid #CBCCCF;
		text-align: center;
		padding: 25px 0 10px;
		}
		/* Discount Code ------------------------------ */

		.discount {
		width: 100%;
		margin: 0;
		padding: 24px;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		background-color: #F4F4F7;
		border: 2px dashed #CBCCCF;
		}

		.discount_heading {
		text-align: center;
		}

		.discount_body {
		text-align: center;
		font-size: 15px;
		}
		/* Social Icons ------------------------------ */

		.social {
		width: auto;
		}

		.social td {
		padding: 0;
		width: auto;
		}

		.social_icon {
		height: 20px;
		margin: 0 8px 10px 8px;
		padding: 0;
		}
		/* Data table ------------------------------ */

		.purchase {
		width: 100%;
		margin: 0;
		padding: 35px 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		}

		.purchase_content {
		width: 100%;
		margin: 0;
		padding: 25px 0 0 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		}

		.purchase_item {
		padding: 10px 0;
		color: #51545E;
		font-size: 15px;
		line-height: 18px;
		}

		.purchase_heading {
		padding-bottom: 8px;
		border-bottom: 1px solid #EAEAEC;
		}

		.purchase_heading p {
		margin: 0;
		color: #85878E;
		font-size: 12px;
		}

		.purchase_footer {
		padding-top: 15px;
		border-top: 1px solid #EAEAEC;
		}

		.purchase_total {
		margin: 0;
		text-align: right;
		font-weight: bold;
		color: #333333;
		}

		.purchase_total--label {
		padding: 0 15px 0 0;
		}

		body {
		background-color: #F2F4F6;
		color: #51545E;
		}

		p {
		color: #51545E;
		}

		.email-wrapper {
		width: 100%;
		margin: 0;
		padding: 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		background-color: #F2F4F6;
		}

		.email-content {
		width: 100%;
		margin: 0;
		padding: 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		}
		/* Masthead ----------------------- */

		.email-masthead {
		padding: 25px 0;
		text-align: center;
		}

		.email-masthead_logo {
		width: 94px;
		}

		.email-masthead_name {
		font-size: 16px;
		font-weight: bold;
		color: #A8AAAF;
		text-decoration: none;
		text-shadow: 0 1px 0 white;
		}
		/* Body ------------------------------ */

		.email-body {
		width: 100%;
		margin: 0;
		padding: 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		}

		.email-body_inner {
		width: 570px;
		margin: 0 auto;
		padding: 0;
		-premailer-width: 570px;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		background-color: #FFFFFF;
		}

		.email-footer {
		width: 570px;
		margin: 0 auto;
		padding: 0;
		-premailer-width: 570px;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		text-align: center;
		}

		.email-footer p {
		color: #A8AAAF;
		}

		.body-action {
		width: 100%;
		margin: 30px auto;
		padding: 0;
		-premailer-width: 100%;
		-premailer-cellpadding: 0;
		-premailer-cellspacing: 0;
		text-align: center;
		}

		.body-sub {
		margin-top: 25px;
		padding-top: 25px;
		border-top: 1px solid #EAEAEC;
		}

		.content-cell {
		padding: 45px;
		}
		/*Media Queries ------------------------------ */

		@media only screen and (max-width: 600px) {
		.email-body_inner,
		.email-footer {
		  width: 100% !important;
		}
		}

		@media (prefers-color-scheme: dark) {
		body,
		.email-body,
		.email-body_inner,
		.email-content,
		.email-wrapper,
		.email-masthead,
		.email-footer {
		  background-color: #333333 !important;
		  color: #FFF !important;
		}
		p,
		ul,
		ol,
		blockquote,
		h1,
		h2,
		h3 {
		  color: #FFF !important;
		}
		.attributes_content,
		.discount {
		  background-color: #51545e !important;
		}
		.email-masthead_name {
		  text-shadow: none !important;
		}
		}
		</style>
		<!--[if mso]>
		<style type="text/css">
		.f-fallback  {
		  font-family: Arial, sans-serif;
		}
		</style>
		<![endif]-->
		</head>
		<body id="body">
		<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		<tr>
		  <td align="center">
		    <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		      <tr>
		        <td class="email-masthead">
		          <a href="
HEREDOK1;
		$email_msg .= base_url();
		$email_msg .= <<<HEREDOK2
		" class="f-fallback email-masthead_name"><font color="#A8AAAF">
HEREDOK2;
		$email_msg .= $system_name;
		$email_msg .= <<<HEREDOK3
		</font></a>
		</td>
		</tr>
		<!-- Email Body -->
		<tr>
		<td class="email-body" width="570" cellpadding="0" cellspacing="0">
		  <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
		    <!-- Body content -->
		    <tr>
		      <td class="content-cell">
		        <div class="f-fallback">
		          <h1>Hi&nbsp;
HEREDOK3;
$email_msg .= $first_name;
$email_msg .= <<<HEREDOK4
,</h1><p>Thank you for creating an account. In order to begin using our services, we need to authenticate your account. Please click the link below to verify your email.</p>
		          <!-- Action -->
		          <table class="body-action" align="center" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		            <tr>
		              <td align="center">
		                <table width="100%" border="0" cellspacing="0" cellpadding="0" role="presentation">
		                  <tr>
		                    <td align="center">
		                      <a href="
HEREDOK4;
		$email_msg .= $redirect_url;
		$email_msg .= <<<HEREDOK6
		" class="f-fallback button button--green" target="_blank"><font color="#ffffff">Verify your email</font></a>
		                    </td>
		                  </tr>
		                </table>
		              </td>
		            </tr>
		          </table>
		          <hr><table>
		            <tr>
		              <td>
		                <p>Thanks,
		                <br>The&nbsp;
HEREDOK6;
		$email_msg .= $system_name;
		$email_msg .= <<<HEREDOK7
		Team</p>
		              </td>
		            </tr>
		          </table>
		        </div>
		      </td>
		    </tr>
		  </table>
		</td>
		</tr>
		<tr>
		<td>
		  <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
		    <tr>
		      <td class="content-cell" align="center">
		        <p class="f-fallback sub align-center">&copy; 2020&nbsp;
HEREDOK7;
		$email_msg .= $system_name;
		$email_msg .= <<<HEREDOK8
		. All rights reserved.</p>
		      </td>
		    </tr>
		  </table>
		</td>
		</tr>
		</table>
		</td>
		</tr>
		</table>
		</body>
		</html>
HEREDOK8;
		$this->send_smtp_mail($email_msg, $subject, $to);
	}

	public function send_mail_on_course_status_changing($course_id = "", $mail_subject = "", $mail_body = "") {
		$instructor_id		 = 0;
		$course_details    = $this->crud_model->get_course_by_id($course_id)->row_array();
		if ($course_details['user_id'] != "") {
			$instructor_id = $course_details['user_id'];
		}else {
			$instructor_id = $this->session->userdata('user_id');
		}
		$instuctor_details = $this->user_model->get_all_user($instructor_id)->row_array();
		$email_from = get_settings('system_email');

		$this->send_smtp_mail($mail_body, $mail_subject, $instuctor_details['email'], $email_from);
	}

	public function course_purchase_notification($student_id = "", $payment_method = "", $amount_paid = ""){
		$purchased_courses 	= $this->session->userdata('cart_items');
		$student_data 		= $this->user_model->get_user($student_id)->row_array();
		$student_full_name 	= $student_data['first_name'].' '.$student_data['last_name'];
		$admin_id 			= $this->user_model->get_admin_details()->row('id');
	    foreach ($purchased_courses as $course_id) {
	    	$course_owner_user_id = $this->crud_model->get_course_by_id($course_id)->row('user_id');
	    	if($course_owner_user_id == $admin_id):
				$this->course_purchase_notification_instructor($course_id, $student_full_name, $student_data['email']);
				$this->course_purchase_notification_student($course_id, $student_id);
			else:
				$this->course_purchase_notification_admin($course_id, $student_full_name, $student_data['email'], $amount_paid);
				$this->course_purchase_notification_instructor($course_id, $student_full_name, $student_data['email']);
				$this->course_purchase_notification_student($course_id, $student_id);
			endif;
	    }
	}

	public function course_purchase_notification_admin($course_id = "", $student_full_name = "", $student_email = "", $amount = ""){
		$course_details = $this->crud_model->get_course_by_id($course_id)->row_array();
		$amount = $this->db->get_where('course' , array('id' => $course_id))->row()->discounted_price;
		$first_name = $this->db->get_where('users' , array('role_id' => '1'))->row()->first_name;
		$system_name = $this->db->get_where('settings', array('key' => 'system_name'))->row()->value;
		$admin_email_to = $this->user_model->get_admin_details()->row('email');
		$instructor_details = $this->db->get_where('users', array('id' => $course_details['user_id']))->row_array();
		$subject = "Course Purchased";
		$admin_msg	=	<<<HEREDOG1
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
		<html>
		<head>
		    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
		    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		    <title></title>
		    <style type="text/css" rel="stylesheet" media="all">
		        /* Base ------------------------------ */

		        @import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
		        body {
		            width: 100% !important;
		            height: 100%;
		            margin: 0;
		            -webkit-text-size-adjust: none;
		        }

		        a {
		            color: #3869D4 !important;
		        }

		        a img {
		            border: none;
		        }

		        td {
		            word-break: break-word;
		        }

		        .preheader {
		            display: none !important;
		            visibility: hidden;
		            mso-hide: all;
		            font-size: 1px;
		            line-height: 1px;
		            max-height: 0;
		            max-width: 0;
		            opacity: 0;
		            overflow: hidden;
		        }
		        /* Type ------------------------------ */

		        body,
		        td,
		        th {
		            font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
		        }

		        h1 {
		            margin-top: 0;
		            color: #333333;
		            font-size: 22px;
		            font-weight: bold;
		            text-align: left;
		        }

		        h2 {
		            margin-top: 0;
		            color: #333333;
		            font-size: 16px;
		            font-weight: bold;
		            text-align: left;
		        }

		        h3 {
		            margin-top: 0;
		            color: #333333;
		            font-size: 14px;
		            font-weight: bold;
		            text-align: left;
		        }

		        td,
		        th {
		            font-size: 16px;
		        }

		        p,
		        ul,
		        ol,
		        blockquote {
		            margin: .4em 0 1.1875em;
		            font-size: 16px;
		            line-height: 1.625;
		        }

		        hr {
		            border-top: 1px solid #fff;
		        }

		        p.sub {
		            font-size: 13px;
		        }
		        /* Utilities ------------------------------ */

		        .align-right {
		            text-align: right;
		        }

		        .align-left {
		            text-align: left;
		        }

		        .align-center {
		            text-align: center;
		        }
		        /* Buttons ------------------------------ */

		        .button {
		            background-color: #3869D4;
		            border-top: 10px solid #3869D4;
		            border-right: 18px solid #3869D4;
		            border-bottom: 10px solid #3869D4;
		            border-left: 18px solid #3869D4;
		            display: inline-block;
		            color: #FFF;
		            text-decoration: none;
		            border-radius: 3px;
		            box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
		            -webkit-text-size-adjust: none;
		            box-sizing: border-box;
		        }

		        .button--green {
		            background-color: #22BC66;
		            border-top: 10px solid #22BC66;
		            border-right: 18px solid #22BC66;
		            border-bottom: 10px solid #22BC66;
		            border-left: 18px solid #22BC66;
		        }

		        .button--red {
		            background-color: #FF6136;
		            border-top: 10px solid #FF6136;
		            border-right: 18px solid #FF6136;
		            border-bottom: 10px solid #FF6136;
		            border-left: 18px solid #FF6136;
		        }

		        @media only screen and (max-width: 500px) {
		            .button {
		                width: 100% !important;
		                text-align: center !important;
		            }
		        }
		        /* Attribute list ------------------------------ */

		        .attributes {
		            margin: 0 0 21px;
		        }

		        .attributes_content {
		            background-color: #F4F4F7;
		            padding: 16px;
		        }

		        .attributes_item {
		            padding: 0;
		        }
		        /* Related Items ------------------------------ */

		        .related {
		            width: 100%;
		            margin: 0;
		            padding: 25px 0 0 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		        }

		        .related_item {
		            padding: 10px 0;
		            color: #CBCCCF;
		            font-size: 15px;
		            line-height: 18px;
		        }

		        .related_item-title {
		            display: block;
		            margin: .5em 0 0;
		        }

		        .related_item-thumb {
		            display: block;
		            padding-bottom: 10px;
		        }

		        .related_heading {
		            border-top: 1px solid #CBCCCF;
		            text-align: center;
		            padding: 25px 0 10px;
		        }
		        /* Discount Code ------------------------------ */

		        .discount {
		            width: 100%;
		            margin: 0;
		            padding: 24px;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		            background-color: #F4F4F7;
		            border: 2px dashed #CBCCCF;
		        }

		        .discount_heading {
		            text-align: center;
		        }

		        .discount_body {
		            text-align: center;
		            font-size: 15px;
		        }
		        /* Social Icons ------------------------------ */

		        .social {
		            width: auto;
		        }

		        .social td {
		            padding: 0;
		            width: auto;
		        }

		        .social_icon {
		            height: 20px;
		            margin: 0 8px 10px 8px;
		            padding: 0;
		        }
		        /* Data table ------------------------------ */

		        .purchase {
		            width: 100%;
		            margin: 0;
		            padding: 35px 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		        }

		        .purchase_content {
		            width: 100%;
		            margin: 0;
		            padding: 25px 0 0 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		        }

		        .purchase_item {
		            padding: 10px 0;
		            color: #51545E;
		            font-size: 15px;
		            line-height: 18px;
		        }

		        .purchase_heading {
		            padding-bottom: 8px;
		            border-bottom: 1px solid #EAEAEC;
		        }

		        .purchase_heading p {
		            margin: 0;
		            color: #85878E;
		            font-size: 12px;
		        }

		        .purchase_footer {
		            padding-top: 15px;
		            border-top: 1px solid #EAEAEC;
		        }

		        .purchase_total {
		            margin: 0;
		            text-align: right;
		            font-weight: bold;
		            color: #333333;
		        }

		        .purchase_total--label {
		            padding: 0 15px 0 0;
		        }

		        body {
		            background-color: #F2F4F6;
		            color: #51545E;
		        }

		        p {
		            color: #51545E;
		        }

		        .email-wrapper {
		            width: 100%;
		            margin: 0;
		            padding: 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		            background-color: #F2F4F6;
		        }

		        .email-content {
		            width: 100%;
		            margin: 0;
		            padding: 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		        }
		        /* Masthead ----------------------- */

		        .email-masthead {
		            padding: 25px 0;
		            text-align: center;
		        }

		        .email-masthead_logo {
		            width: 94px;
		        }

		        .email-masthead_name {
		            font-size: 16px;
		            font-weight: bold;
		            color: #A8AAAF;
		            text-decoration: none;
		            text-shadow: 0 1px 0 white;
		        }
		        /* Body ------------------------------ */

		        .email-body {
		            width: 100%;
		            margin: 0;
		            padding: 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		        }

		        .email-body_inner {
		            width: 570px;
		            margin: 0 auto;
		            padding: 0;
		            -premailer-width: 570px;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		            background-color: #FFFFFF;
		        }

		        .email-footer {
		            width: 570px;
		            margin: 0 auto;
		            padding: 0;
		            -premailer-width: 570px;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		            text-align: center;
		        }

		        .email-footer p {
		            color: #A8AAAF;
		        }

		        .body-action {
		            width: 100%;
		            margin: 30px auto;
		            padding: 0;
		            -premailer-width: 100%;
		            -premailer-cellpadding: 0;
		            -premailer-cellspacing: 0;
		            text-align: center;
		        }

		        .body-sub {
		            margin-top: 25px;
		            padding-top: 25px;
		            border-top: 1px solid #EAEAEC;
		        }

		        .content-cell {
		            padding: 45px;
		        }
		        /*Media Queries ------------------------------ */

		        @media only screen and (max-width: 600px) {
		            .email-body_inner,
		            .email-footer {
		                width: 100% !important;
		            }
		        }

		        @media (prefers-color-scheme: dark) {
		            body,
		            .email-body,
		            .email-body_inner,
		            .email-content,
		            .email-wrapper,
		            .email-masthead,
		            .email-footer {
		                background-color: #333333 !important;
		                color: #FFF !important;
		            }
		            p,
		            ul,
		            ol,
		            blockquote,
		            h1,
		            h2,
		            h3 {
		                color: #FFF !important;
		            }
		            .attributes_content,
		            .discount {
		                background-color: #51545e !important;
		            }
		            .email-masthead_name {
		                text-shadow: none !important;
		            }
		        }
		    </style>
		    <!--[if mso]>
				<style type="text/css">
				.f-fallback  {
				  font-family: Arial, sans-serif;
				}
				</style>
				<![endif]-->
		</head>

		<body id="body">
		    <table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		        <tr>
		            <td align="center">
		                <table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		                    <tr>
		                        <td class="email-masthead">
		                            <a href="
HEREDOG1;
		$admin_msg .= base_url();
		$admin_msg .= <<<HEREDOG11
" class="f-fallback email-masthead_name"><font color="#A8AAAF">
HEREDOG11;
		$admin_msg .= $system_name;
		$admin_msg .= <<<HEREDOG2
</font></a>
		                        </td>
		                    </tr>
		                    <!-- Email Body -->
		                    <tr>
		                        <td class="email-body" width="570" cellpadding="0" cellspacing="0">
		                            <table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
		                                <!-- Body content -->
		                                <tr>
		                                    <td class="content-cell">
		                                        <div class="f-fallback">
		                                            <h1>Hi&nbsp;
HEREDOG2;
$admin_msg .= $first_name;
$admin_msg .= <<<HEREDOG3
,</h1>
		                                            <p>One of the courses has been purchased. Below are the details of the instructor and student.</p>
													<h2 class="f-fallback discount_heading"><font color="#51545e">Course Details</font></h2>
		                                            <table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
		                                                <tr>
		                                                    <td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
		                                                        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
		                                                                    <span class="f-fallback"><font color="#51545e">
				<strong>Title&nbsp;:&nbsp;</strong>
HEREDOG3;
$admin_msg .= $course_details['title'];
$admin_msg .= <<<HEREDOG4
</font></span>
		                                                                </td>
		                                                            </tr>
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
		                                                                    <span class="f-fallback"><font color="#51545e">
				<strong>Price&nbsp;:&nbsp;</strong>
HEREDOG4;
$admin_msg .= "₹".$amount;
$admin_msg .= <<<HEREDOG5
</font></span>
		                                                                </td>
		                                                            </tr>
		                                                        </table>
		                                                    </td>
		                                                </tr>
		                                            </table>
		                                            </h1>
		                                            <h2 class="f-fallback discount_heading"><font color="#51545e">Instructor Details</font></h2>
		                                            <table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
		                                                <tr>
		                                                    <td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
		                                                        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
		                                                                    <span class="f-fallback"><font color="#51545e">
				<strong>Name&nbsp;:&nbsp;</strong>
HEREDOG5;
$admin_msg .= $instructor_details['first_name']." ".$instructor_details['last_name'];
$admin_msg .= <<<HEREDOG6
</font></span>
		                                                                </td>
		                                                            </tr>
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																		<a href="" class="f-fallback"><font color="#51545e"><strong>Email&nbsp;:&nbsp;</strong>
HEREDOG6;
$admin_msg .= $instructor_details['email'];
$admin_msg .= <<<HEREDOG7
		                                                                </td>
		                                                            </tr>
		                                                        </table>
		                                                    </td>
		                                                </tr>
		                                            </table>
		                                            <table>
													<h2 class="f-fallback discount_heading"><font color="#51545e">Student Details</font></h2>
		                                            <table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
		                                                <tr>
		                                                    <td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
		                                                        <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
		                                                                    <span class="f-fallback"><font color="#51545e">
				<strong>Name&nbsp;:&nbsp;</strong>
HEREDOG7;
$admin_msg .= $student_full_name;
$admin_msg .= <<<HEREDOG8
</font></span>
		                                                                </td>
		                                                            </tr>
		                                                            <tr>
		                                                                <td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																		<a href="" class="f-fallback"><font color="#51545e"><strong>Email&nbsp;:&nbsp;</strong>
HEREDOG8;
$admin_msg .= $student_email;
$admin_msg .= <<<HEREDOG9
																																		</font></a>
		                                                                </td>
		                                                            </tr>
		                                                        </table>
		                                                    </td>
		                                                </tr>
		                                            </table>
																								<p><strong>P.S.</strong> If you have any questions or need any help, please don't hesitate to reach out.</p>
		                                            <hr><table>
		                                                <tr>
		                                                    <td>
		                                                        <p>Thanks,
		                                                            <br>The&nbsp;
HEREDOG9;
$admin_msg .= $system_name;
$admin_msg .= <<<HEREDOG10
Team
		                                                        </p>
		                                                    </td>
		                                                </tr>
		                                            </table>
		                                        </div>
		                                    </td>
		                                </tr>
		                            </table>
		                        </td>
		                    </tr>
		                    <tr>
		                        <td>
		                            <table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
		                                <tr>
		                                    <td class="content-cell" align="center">
		                                        <p class="f-fallback sub align-center">&copy; 2020&nbsp;
HEREDOG10;
$admin_msg .= $system_name;
$admin_msg .= <<<HEREDOG12
. All rights reserved.</p>
		                                    </td>
		                                </tr>
		                            </table>
		                        </td>
		                    </tr>
		                </table>
		            </td>
		        </tr>
		    </table>
		</body>

		</html>
HEREDOG12;
		$this->send_smtp_mail($admin_msg, $subject, $admin_email_to);
	}

	public function course_purchase_notification_instructor($course_id = "",$student_full_name = "", $student_email = ""){
		$course_details = $this->crud_model->get_course_by_id($course_id)->row_array();
		$instructor_email_to = $this->db->get_where('users', array('id' => $course_details['user_id']))->row()->email;
		$system_name = $this->db->get_where('settings', array('key' => 'system_name'))->row()->value;
		$amount = $this->db->get_where('course' , array('id' => $course_id))->row()->discounted_price;
		$first_name = $this->db->get_where('users', array('id' => $course_details['user_id']))->row()->first_name;
		$subject = "Course Purchased";
		$instructor_msg	=	<<<HEREDOF1
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title></title>
		<style type="text/css" rel="stylesheet" media="all">
				/* Base ------------------------------ */

				@import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
				body {
						width: 100% !important;
						height: 100%;
						margin: 0;
						-webkit-text-size-adjust: none;
				}

				a {
						color: #3869D4 !important;
				}

				a img {
						border: none;
				}

				td {
						word-break: break-word;
				}

				.preheader {
						display: none !important;
						visibility: hidden;
						mso-hide: all;
						font-size: 1px;
						line-height: 1px;
						max-height: 0;
						max-width: 0;
						opacity: 0;
						overflow: hidden;
				}
				/* Type ------------------------------ */

				body,
				td,
				th {
						font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
				}

				h1 {
						margin-top: 0;
						color: #333333;
						font-size: 22px;
						font-weight: bold;
						text-align: left;
				}

				h2 {
						margin-top: 0;
						color: #333333;
						font-size: 16px;
						font-weight: bold;
						text-align: left;
				}

				h3 {
						margin-top: 0;
						color: #333333;
						font-size: 14px;
						font-weight: bold;
						text-align: left;
				}

				td,
				th {
						font-size: 16px;
				}

				p,
				ul,
				ol,
				blockquote {
						margin: .4em 0 1.1875em;
						font-size: 16px;
						line-height: 1.625;
				}

				hr {
						border-top: 1px solid #fff;
				}

				p.sub {
						font-size: 13px;
				}
				/* Utilities ------------------------------ */

				.align-right {
						text-align: right;
				}

				.align-left {
						text-align: left;
				}

				.align-center {
						text-align: center;
				}
				/* Buttons ------------------------------ */

				.button {
						background-color: #3869D4;
						border-top: 10px solid #3869D4;
						border-right: 18px solid #3869D4;
						border-bottom: 10px solid #3869D4;
						border-left: 18px solid #3869D4;
						display: inline-block;
						color: #FFF;
						text-decoration: none;
						border-radius: 3px;
						box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
						-webkit-text-size-adjust: none;
						box-sizing: border-box;
				}

				.button--green {
						background-color: #22BC66;
						border-top: 10px solid #22BC66;
						border-right: 18px solid #22BC66;
						border-bottom: 10px solid #22BC66;
						border-left: 18px solid #22BC66;
				}

				.button--red {
						background-color: #FF6136;
						border-top: 10px solid #FF6136;
						border-right: 18px solid #FF6136;
						border-bottom: 10px solid #FF6136;
						border-left: 18px solid #FF6136;
				}

				@media only screen and (max-width: 500px) {
						.button {
								width: 100% !important;
								text-align: center !important;
						}
				}
				/* Attribute list ------------------------------ */

				.attributes {
						margin: 0 0 21px;
				}

				.attributes_content {
						background-color: #F4F4F7;
						padding: 16px;
				}

				.attributes_item {
						padding: 0;
				}
				/* Related Items ------------------------------ */

				.related {
						width: 100%;
						margin: 0;
						padding: 25px 0 0 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
				}

				.related_item {
						padding: 10px 0;
						color: #CBCCCF;
						font-size: 15px;
						line-height: 18px;
				}

				.related_item-title {
						display: block;
						margin: .5em 0 0;
				}

				.related_item-thumb {
						display: block;
						padding-bottom: 10px;
				}

				.related_heading {
						border-top: 1px solid #CBCCCF;
						text-align: center;
						padding: 25px 0 10px;
				}
				/* Discount Code ------------------------------ */

				.discount {
						width: 100%;
						margin: 0;
						padding: 24px;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
						background-color: #F4F4F7;
						border: 2px dashed #CBCCCF;
				}

				.discount_heading {
						text-align: center;
				}

				.discount_body {
						text-align: center;
						font-size: 15px;
				}
				/* Social Icons ------------------------------ */

				.social {
						width: auto;
				}

				.social td {
						padding: 0;
						width: auto;
				}

				.social_icon {
						height: 20px;
						margin: 0 8px 10px 8px;
						padding: 0;
				}
				/* Data table ------------------------------ */

				.purchase {
						width: 100%;
						margin: 0;
						padding: 35px 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
				}

				.purchase_content {
						width: 100%;
						margin: 0;
						padding: 25px 0 0 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
				}

				.purchase_item {
						padding: 10px 0;
						color: #51545E;
						font-size: 15px;
						line-height: 18px;
				}

				.purchase_heading {
						padding-bottom: 8px;
						border-bottom: 1px solid #EAEAEC;
				}

				.purchase_heading p {
						margin: 0;
						color: #85878E;
						font-size: 12px;
				}

				.purchase_footer {
						padding-top: 15px;
						border-top: 1px solid #EAEAEC;
				}

				.purchase_total {
						margin: 0;
						text-align: right;
						font-weight: bold;
						color: #333333;
				}

				.purchase_total--label {
						padding: 0 15px 0 0;
				}

				body {
						background-color: #F2F4F6;
						color: #51545E;
				}

				p {
						color: #51545E;
				}

				.email-wrapper {
						width: 100%;
						margin: 0;
						padding: 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
						background-color: #F2F4F6;
				}

				.email-content {
						width: 100%;
						margin: 0;
						padding: 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
				}
				/* Masthead ----------------------- */

				.email-masthead {
						padding: 25px 0;
						text-align: center;
				}

				.email-masthead_logo {
						width: 94px;
				}

				.email-masthead_name {
						font-size: 16px;
						font-weight: bold;
						color: #A8AAAF;
						text-decoration: none;
						text-shadow: 0 1px 0 white;
				}
				/* Body ------------------------------ */

				.email-body {
						width: 100%;
						margin: 0;
						padding: 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
				}

				.email-body_inner {
						width: 570px;
						margin: 0 auto;
						padding: 0;
						-premailer-width: 570px;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
						background-color: #FFFFFF;
				}

				.email-footer {
						width: 570px;
						margin: 0 auto;
						padding: 0;
						-premailer-width: 570px;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
						text-align: center;
				}

				.email-footer p {
						color: #A8AAAF;
				}

				.body-action {
						width: 100%;
						margin: 30px auto;
						padding: 0;
						-premailer-width: 100%;
						-premailer-cellpadding: 0;
						-premailer-cellspacing: 0;
						text-align: center;
				}

				.body-sub {
						margin-top: 25px;
						padding-top: 25px;
						border-top: 1px solid #EAEAEC;
				}

				.content-cell {
						padding: 45px;
				}
				/*Media Queries ------------------------------ */

				@media only screen and (max-width: 600px) {
						.email-body_inner,
						.email-footer {
								width: 100% !important;
						}
				}

				@media (prefers-color-scheme: dark) {
						body,
						.email-body,
						.email-body_inner,
						.email-content,
						.email-wrapper,
						.email-masthead,
						.email-footer {
								background-color: #333333 !important;
								color: #FFF !important;
						}
						p,
						ul,
						ol,
						blockquote,
						h1,
						h2,
						h3 {
								color: #FFF !important;
						}
						.attributes_content,
						.discount {
								background-color: #51545e !important;
						}
						.email-masthead_name {
								text-shadow: none !important;
						}
				}
		</style>
		<!--[if mso]>
		<style type="text/css">
		.f-fallback  {
			font-family: Arial, sans-serif;
		}
		</style>
		<![endif]-->
</head>

<body id="body">
		<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
				<tr>
						<td align="center">
								<table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
										<tr>
												<td class="email-masthead">
														<a href="
HEREDOF1;
$instructor_msg .= base_url();
$instructor_msg .= <<<HEREDOF2
" class="f-fallback email-masthead_name"><font color="#A8AAAF">
HEREDOF2;
$instructor_msg .= $system_name;
$instructor_msg .= <<<HEREDOF3
</font></a>
												</td>
										</tr>
										<!-- Email Body -->
										<tr>
												<td class="email-body" width="570" cellpadding="0" cellspacing="0">
														<table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
																<!-- Body content -->
																<tr>
																		<td class="content-cell">
																				<div class="f-fallback">
																						<h1>Hi&nbsp;
HEREDOF3;
$instructor_msg .= $first_name;
$instructor_msg .= <<<HEREDOF4
,</h1>
																						<p>One of your courses has been purchased. Below are the details of the course and student.</p>
											<h2 class="f-fallback discount_heading"><font color="#51545e">Course Details</font></h2>
																						<table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
																								<tr>
																										<td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
																												<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
																														<tr>
																																<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																		<span class="f-fallback"><font color="#51545e">
		<strong>Title&nbsp;:&nbsp;</strong>
HEREDOF4;
$instructor_msg .= $course_details['title'];
$instructor_msg .= <<<HEREDOF5
</font></span>
																																</td>
																														</tr>
																														<tr>
																																<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																		<span class="f-fallback"><font color="#51545e">
		<strong>Price&nbsp;:&nbsp;</strong>
HEREDOF5;
$instructor_msg .= "₹".$amount;
$instructor_msg .= <<<HEREDOF6
</font></span>
																																</td>
																														</tr>
																												</table>
																										</td>
																								</tr>
																						</table>
																						</h1>

											<h2 class="f-fallback discount_heading"><font color="#51545e">Student Details</font></h2>
																						<table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
																								<tr>
																										<td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
																												<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
																														<tr>
																																<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																		<span class="f-fallback"><font color="#51545e">
		<strong>Name&nbsp;:&nbsp;</strong>
HEREDOF6;
$instructor_msg .= $student_full_name;
$instructor_msg .= <<<HEREDOF7
</font></span>
																																</td>
																														</tr>
																														<tr>
																																<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
                                                                <a href="" class="f-fallback"><font color="#51545e"><strong>Email&nbsp;:&nbsp;</strong>
HEREDOF7;
$instructor_msg .= $student_email;
$instructor_msg .= <<<HEREDOF8
</font></a>																											</td>
																														</tr>
																												</table>
																										</td>
																								</tr>
																						</table>
																						<p><strong>P.S.</strong> If you have any questions or need any help, please don't hesitate to reach out.</p>
																						<hr><table>
																								<tr>
																										<td>
																												<p>Thanks,
																														<br>The&nbsp;
HEREDOF8;
$instructor_msg .= $system_name;
$instructor_msg .= <<<HEREDOF9
Team
																												</p>
																										</td>
																								</tr>
																						</table>
																				</div>
																		</td>
																</tr>
														</table>
												</td>
										</tr>
										<tr>
												<td>
														<table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
																<tr>
																		<td class="content-cell" align="center">
																				<p class="f-fallback sub align-center">&copy; 2020&nbsp;
HEREDOF9;
$instructor_msg .= $system_name;
$instructor_msg .= <<<HEREDOF10
. All rights reserved.</p>
																		</td>
																</tr>
														</table>
												</td>
										</tr>
								</table>
						</td>
				</tr>
		</table>
</body>

</html>
HEREDOF10;
		$this->send_smtp_mail($instructor_msg, $subject, $instructor_email_to);
	}

	public function course_purchase_notification_student($course_id = "", $student_id = ""){
		$course_details = $this->crud_model->get_course_by_id($course_id)->row_array();
		$amount = $this->db->get_where('course', array('id' => $course_id))->row()->discounted_price;
		$first_name = $this->db->get_where('users', array('id' => $student_id))->row()->first_name;
		$system_name = $this->db->get_where('settings', array('key' => 'system_name'))->row()->value;
		$student_email_to = $this->user_model->get_user($student_id)->row('email');
		$instructor_details = $this->db->get_where('users', array('id' => $course_details['user_id']))->row_array();
		$subject = "Course Purchased";
		$student_msg	=	<<<HEREDOJ1
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title></title>
<style type="text/css" rel="stylesheet" media="all">
		/* Base ------------------------------ */

		@import url("https://fonts.googleapis.com/css?family=Nunito+Sans:400,700&display=swap");
		body {
				width: 100% !important;
				height: 100%;
				margin: 0;
				-webkit-text-size-adjust: none;
		}

		a {
				color: #3869D4 !important;
		}

		a img {
				border: none;
		}

		td {
				word-break: break-word;
		}

		.preheader {
				display: none !important;
				visibility: hidden;
				mso-hide: all;
				font-size: 1px;
				line-height: 1px;
				max-height: 0;
				max-width: 0;
				opacity: 0;
				overflow: hidden;
		}
		/* Type ------------------------------ */

		body,
		td,
		th {
				font-family: "Nunito Sans", Helvetica, Arial, sans-serif;
		}

		h1 {
				margin-top: 0;
				color: #333333;
				font-size: 22px;
				font-weight: bold;
				text-align: left;
		}

		h2 {
				margin-top: 0;
				color: #333333;
				font-size: 16px;
				font-weight: bold;
				text-align: left;
		}

		h3 {
				margin-top: 0;
				color: #333333;
				font-size: 14px;
				font-weight: bold;
				text-align: left;
		}

		td,
		th {
				font-size: 16px;
		}

		p,
		ul,
		ol,
		blockquote {
				margin: .4em 0 1.1875em;
				font-size: 16px;
				line-height: 1.625;
		}

		hr {
				border-top: 1px solid #fff;
		}

		p.sub {
				font-size: 13px;
		}
		/* Utilities ------------------------------ */

		.align-right {
				text-align: right;
		}

		.align-left {
				text-align: left;
		}

		.align-center {
				text-align: center;
		}
		/* Buttons ------------------------------ */

		.button {
				background-color: #3869D4;
				border-top: 10px solid #3869D4;
				border-right: 18px solid #3869D4;
				border-bottom: 10px solid #3869D4;
				border-left: 18px solid #3869D4;
				display: inline-block;
				color: #FFF;
				text-decoration: none;
				border-radius: 3px;
				box-shadow: 0 2px 3px rgba(0, 0, 0, 0.16);
				-webkit-text-size-adjust: none;
				box-sizing: border-box;
		}

		.button--green {
				background-color: #22BC66;
				border-top: 10px solid #22BC66;
				border-right: 18px solid #22BC66;
				border-bottom: 10px solid #22BC66;
				border-left: 18px solid #22BC66;
		}

		.button--red {
				background-color: #FF6136;
				border-top: 10px solid #FF6136;
				border-right: 18px solid #FF6136;
				border-bottom: 10px solid #FF6136;
				border-left: 18px solid #FF6136;
		}

		@media only screen and (max-width: 500px) {
				.button {
						width: 100% !important;
						text-align: center !important;
				}
		}
		/* Attribute list ------------------------------ */

		.attributes {
				margin: 0 0 21px;
		}

		.attributes_content {
				background-color: #F4F4F7;
				padding: 16px;
		}

		.attributes_item {
				padding: 0;
		}
		/* Related Items ------------------------------ */

		.related {
				width: 100%;
				margin: 0;
				padding: 25px 0 0 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
		}

		.related_item {
				padding: 10px 0;
				color: #CBCCCF;
				font-size: 15px;
				line-height: 18px;
		}

		.related_item-title {
				display: block;
				margin: .5em 0 0;
		}

		.related_item-thumb {
				display: block;
				padding-bottom: 10px;
		}

		.related_heading {
				border-top: 1px solid #CBCCCF;
				text-align: center;
				padding: 25px 0 10px;
		}
		/* Discount Code ------------------------------ */

		.discount {
				width: 100%;
				margin: 0;
				padding: 24px;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
				background-color: #F4F4F7;
				border: 2px dashed #CBCCCF;
		}

		.discount_heading {
				text-align: center;
		}

		.discount_body {
				text-align: center;
				font-size: 15px;
		}
		/* Social Icons ------------------------------ */

		.social {
				width: auto;
		}

		.social td {
				padding: 0;
				width: auto;
		}

		.social_icon {
				height: 20px;
				margin: 0 8px 10px 8px;
				padding: 0;
		}
		/* Data table ------------------------------ */

		.purchase {
				width: 100%;
				margin: 0;
				padding: 35px 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
		}

		.purchase_content {
				width: 100%;
				margin: 0;
				padding: 25px 0 0 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
		}

		.purchase_item {
				padding: 10px 0;
				color: #51545E;
				font-size: 15px;
				line-height: 18px;
		}

		.purchase_heading {
				padding-bottom: 8px;
				border-bottom: 1px solid #EAEAEC;
		}

		.purchase_heading p {
				margin: 0;
				color: #85878E;
				font-size: 12px;
		}

		.purchase_footer {
				padding-top: 15px;
				border-top: 1px solid #EAEAEC;
		}

		.purchase_total {
				margin: 0;
				text-align: right;
				font-weight: bold;
				color: #333333;
		}

		.purchase_total--label {
				padding: 0 15px 0 0;
		}

		body {
				background-color: #F2F4F6;
				color: #51545E;
		}

		p {
				color: #51545E;
		}

		.email-wrapper {
				width: 100%;
				margin: 0;
				padding: 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
				background-color: #F2F4F6;
		}

		.email-content {
				width: 100%;
				margin: 0;
				padding: 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
		}
		/* Masthead ----------------------- */

		.email-masthead {
				padding: 25px 0;
				text-align: center;
		}

		.email-masthead_logo {
				width: 94px;
		}

		.email-masthead_name {
				font-size: 16px;
				font-weight: bold;
				color: #A8AAAF;
				text-decoration: none;
				text-shadow: 0 1px 0 white;
		}
		/* Body ------------------------------ */

		.email-body {
				width: 100%;
				margin: 0;
				padding: 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
		}

		.email-body_inner {
				width: 570px;
				margin: 0 auto;
				padding: 0;
				-premailer-width: 570px;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
				background-color: #FFFFFF;
		}

		.email-footer {
				width: 570px;
				margin: 0 auto;
				padding: 0;
				-premailer-width: 570px;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
				text-align: center;
		}

		.email-footer p {
				color: #A8AAAF;
		}

		.body-action {
				width: 100%;
				margin: 30px auto;
				padding: 0;
				-premailer-width: 100%;
				-premailer-cellpadding: 0;
				-premailer-cellspacing: 0;
				text-align: center;
		}

		.body-sub {
				margin-top: 25px;
				padding-top: 25px;
				border-top: 1px solid #EAEAEC;
		}

		.content-cell {
				padding: 45px;
		}
		/*Media Queries ------------------------------ */

		@media only screen and (max-width: 600px) {
				.email-body_inner,
				.email-footer {
						width: 100% !important;
				}
		}

		@media (prefers-color-scheme: dark) {
				body,
				.email-body,
				.email-body_inner,
				.email-content,
				.email-wrapper,
				.email-masthead,
				.email-footer {
						background-color: #333333 !important;
						color: #FFF !important;
				}
				p,
				ul,
				ol,
				blockquote,
				h1,
				h2,
				h3 {
						color: #FFF !important;
				}
				.attributes_content,
				.discount {
						background-color: #51545e !important;
				}
				.email-masthead_name {
						text-shadow: none !important;
				}
		}
</style>
<!--[if mso]>
<style type="text/css">
.f-fallback  {
	font-family: Arial, sans-serif;
}
</style>
<![endif]-->
</head>

<body id="body">
<table class="email-wrapper" width="100%" cellpadding="0" cellspacing="0" role="presentation">
		<tr>
				<td align="center">
						<table class="email-content" width="100%" cellpadding="0" cellspacing="0" role="presentation">
								<tr>
										<td class="email-masthead">
												<a href="
HEREDOJ1;
$student_msg .= base_url();
$student_msg .= <<<HEREDOJ2
" class="f-fallback email-masthead_name"><font color="#A8AAAF">
HEREDOJ2;
$student_msg .= $system_name;
$student_msg .= <<<HEREDOJ3
</font></a>
										</td>
								</tr>
								<!-- Email Body -->
								<tr>
										<td class="email-body" width="570" cellpadding="0" cellspacing="0">
												<table class="email-body_inner" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
														<!-- Body content -->
														<tr>
																<td class="content-cell">
																		<div class="f-fallback">
																				<h1>Hi&nbsp;
HEREDOJ3;
$student_msg .= $first_name;
$student_msg .= <<<HEREDOJ4
,</h1>
																				<p>Thanks you for learning with us. Below are the details of the course you purchased.</p>
									<h2 class="f-fallback discount_heading"><font color="#51545e">Course Details</font></h2>
																				<table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
																						<tr>
																								<td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
																										<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
																												<tr>
																														<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																<span class="f-fallback"><font color="#51545e">
<strong>Title&nbsp;:&nbsp;</strong>
HEREDOJ4;
$student_msg .= $course_details['title'];
$student_msg .= <<<HEREDOJ5
</font></span>
																														</td>
																												</tr>
																												<tr>
																														<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																<span class="f-fallback"><font color="#51545e">
<strong>Price&nbsp;:&nbsp;</strong>
HEREDOJ5;
$student_msg .= "₹".$amount;
$student_msg .= <<<HEREDOJ6
</font></span>
																														</td>
																												</tr>
																										</table>
																								</td>
																						</tr>
																				</table>
																				</h1>

									<h2 class="f-fallback discount_heading"><font color="#51545e">Instructor Details</font></h2>
																				<table class="attributes" width="100%" cellpadding="0" cellspacing="0" role="presentation" style="margin: 0 0 21px;">
																						<tr>
																								<td class="attributes_content" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; background-color: #F4F4F7; padding: 16px;" bgcolor="#F4F4F7">
																										<table width="100%" cellpadding="0" cellspacing="0" role="presentation">
																												<tr>
																														<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
																																<span class="f-fallback"><font color="#51545e">
<strong>Name&nbsp;:&nbsp;</strong>
HEREDOJ6;
$student_msg .= $instructor_details['first_name']." ".$instructor_details['last_name'];
$student_msg .= <<<HEREDOJ7
</font></span>
																														</td>
																												</tr>
																												<tr>
																														<td class="attributes_item" style="word-break: break-word; font-family: &quot;Nunito Sans&quot;, Helvetica, Arial, sans-serif; font-size: 16px; padding: 0;">
                                                            <a href="" class="f-fallback"><font color="#51545e"><strong>Email&nbsp;:&nbsp;</strong>
HEREDOJ7;
$student_msg .= $instructor_details['email'];
$student_msg .= <<<HEREDOJ8
</font></a>
																														</td>
																												</tr>
																										</table>
																								</td>
																						</tr>
																				</table>
																				<p><strong>P.S.</strong> If you have any questions or need any help, please don't hesitate to reach out.</p>
																				<hr><table>
																						<tr>
																								<td>
																										<p>Thanks,
																												<br>The&nbsp;
HEREDOJ8;
$student_msg .= $system_name;
$student_msg .= <<<HEREDOJ9
Team
																										</p>
																								</td>
																						</tr>
																				</table>
																		</div>
																</td>
														</tr>
												</table>
										</td>
								</tr>
								<tr>
										<td>
												<table class="email-footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
														<tr>
																<td class="content-cell" align="center">
																		<p class="f-fallback sub align-center">&copy; 2020&nbsp;
HEREDOJ9;
$student_msg .= $system_name;
$student_msg .= <<<HEREDOJ10
. All rights reserved.</p>
																</td>
														</tr>
												</table>
										</td>
								</tr>
						</table>
				</td>
		</tr>
</table>
</body>

</html>
HEREDOJ10;
		$this->send_smtp_mail($student_msg, $subject, $student_email_to);
	}

	public function notify_on_certificate_generate($user_id = "", $course_id = "") {
		$checker = array(
			'course_id' => $course_id,
			'student_id' => $user_id
		);
		$result = $this->db->get_where('certificates', $checker)->row_array();
		$certificate_link = site_url('certificate/'.$result['shareable_url']);
		$course_details    = $this->crud_model->get_course_by_id($course_id)->row_array();
		$user_details = $this->user_model->get_all_user($user_id)->row_array();
		$email_from = get_settings('system_email');
		$subject 		= "Course Completion Notification";
		$email_msg	=	"<b>Congratulations!!</b> ". $user_details['first_name']." ".$user_details['last_name'].",";
		$email_msg	.=	"<p>You have successfully completed the course named, <b>".$course_details['title'].".</b></p>";
		$email_msg	.=	"<p>You can get your course completion certificate from here <b>".$certificate_link.".</b></p>";
		$this->send_smtp_mail($email_msg, $subject, $user_details['email'], $email_from);
	}

	public function suspended_offline_payment($user_id = ""){
		$user_details = $this->user_model->get_all_user($user_id)->row_array();
		$email_from = get_settings('system_email');
		$subject 	= "Suspended Offline Payment";
		$email_msg  = "<p>Your offline payment has been <b style='color: red;'>suspended</b> !</p>";
		$email_msg .= "<p>Please provide a valid document of your payment.</p>";

		$this->send_smtp_mail($email_msg, $subject, $user_details['email'], $email_from);
	}

	public function send_smtp_mail($msg=NULL, $sub=NULL, $to=NULL, $from=NULL) {
		//Load email library
		$this->load->library('email');

		if($from == NULL)
			$from		=	$this->db->get_where('settings' , array('key' => 'system_email'))->row()->value;

		//SMTP & mail configuration
		$config = array(
			'protocol'  => get_settings('protocol'),
			'smtp_host' => get_settings('smtp_host'),
			'smtp_port' => get_settings('smtp_port'),
			'smtp_user' => get_settings('smtp_user'),
			'smtp_pass' => get_settings('smtp_pass'),
			'mailtype'  => 'html',
			'charset'   => 'utf-8'
		);
		$this->email->initialize($config);
		$this->email->set_mailtype("html");
		$this->email->set_newline("\r\n");

		$htmlContent = $msg;

		$this->email->to($to);
		$this->email->from($from, get_settings('system_name'));
		$this->email->subject($sub);
		$this->email->message($htmlContent);

		//Send email
		$this->email->send();
	}
}
