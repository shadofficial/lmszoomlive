<div class="row ">
  <div class="col-xl-12">
    <div class="card">
      <div class="card-body">
        <h4 class="page-title"> <i class="mdi mdi-apple-keyboard-command title_icon"></i> <?php echo get_phrase('instructor_revenue'); ?></h4>
      </div> <!-- end card body-->
    </div> <!-- end card -->
  </div><!-- end col-->
</div>

<div class="row">
  <div class="col-xl-12">
    <div class="card">
      <div class="card-body">
        <h4 class="mb-3 header-title"><?php echo get_phrase('instructor_revenue'); ?></h4>
        <div class="table-responsive-sm mt-4">
          <table id="basic-datatable" class="table table-striped table-centered mb-0">
            <thead>
              <tr>
                <th><?php echo get_phrase('enrolled_course'); ?></th>
                <th><?php echo get_phrase('instructor'); ?></th>
                <th><?php echo get_phrase('instructor_revenue'); ?></th>
                <th><?php echo get_phrase('status'); ?></th>
                <th class="text-center"><?php echo get_phrase('actions'); ?></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($payment_history as $payment):
                $course_data = $this->db->get_where('course', array('id' => $payment['course_id']))->row_array();
                $user_data = $this->db->get_where('users', array('id' => $course_data['user_id']))->row_array();?>
                <?php
                $paypal_keys          = json_decode($user_data['paypal_keys'], true);
                $stripe_keys          = json_decode($user_data['stripe_keys'], true);
                ?>
                <tr class="gradeU">
                  <td>
                    <strong><a href="<?php echo site_url('home/course/'.slugify($course_data['title']).'/'.$course_data['id']); ?>" target="_blank"><?php echo $course_data['title']; ?></a></strong><br>
                    <small class="text-muted"><?php echo get_phrase('enrolment_date').': '.date('D, d-M-Y', $payment['date_added']); ?></small>
                  </td>
                  <td><?php echo $user_data['first_name'].' '.$user_data['last_name']; ?></td>
                  <td>
                    <?php echo currency($payment['instructor_revenue']); ?><br>
                    <small class="text-muted"><?php echo get_phrase('total_amount').': '.currency($payment['amount']); ?></small>
                  </td>
                  <td style="text-align: center;">
                    <?php if ($payment['instructor_payment_status'] == 0): ?>
                      <div class="label label-secondary"><?php echo get_phrase('pending'); ?></div>
                    <?php elseif($payment['instructor_payment_status'] == 1): ?>
                      <div class="label label-success"><?php echo get_phrase('paid'); ?></div>
                    <?php endif; ?>
                  </td>
                  <td style="text-align: center;">



                    <?php if ($payment['instructor_payment_status'] == 0): ?>
                     <!-- <?php if ($paypal_keys[0]['production_client_id'] != ""): ?>
                        <form action="<?php echo site_url('admin/paypal_checkout_for_instructor_revenue'); ?>" method="post">
                          <input type="hidden" name="amount_to_pay"        value="<?php echo $payment['instructor_revenue']; ?>">
                          <input type="hidden" name="payment_id"           value="<?php echo $payment['id']; ?>">
                          <input type="hidden" name="instructor_name"      value="<?php echo $user_data['first_name'].' '.$user_data['last_name']; ?>">
                          <input type="hidden" name="course_title"         value="<?php echo $course_data['title']; ?>">
                          <input type="hidden" name="production_client_id" value="<?php echo $paypal_keys[0]['production_client_id']; ?>">
                          <input type="submit" class="btn btn-outline-info btn-sm btn-rounded" value="<?php echo get_phrase('pay_with_paypal'); ?>">
                        </form>
                      <?php else: ?>
                        <button type="button" class = "btn btn-outline-danger btn-sm btn-rounded" name="button" onclick="alert('<?php echo get_phrase('this_instructor_has_not_provided_valid_paypal_client_id'); ?>')"><?php echo get_phrase('pay_with_paypal'); ?></button>
                      <?php endif; ?>


                      <?php if ($stripe_keys[0]['public_live_key'] != "" && $stripe_keys[0]['secret_live_key']): ?>
                        <form action="<?php echo site_url('admin/stripe_checkout_for_instructor_revenue'); ?>" method="post">
                          <input type="hidden" name="amount_to_pay"   value="<?php echo $payment['instructor_revenue']; ?>">
                          <input type="hidden" name="payment_id"      value="<?php echo $payment['id']; ?>">
                          <input type="hidden" name="instructor_name" value="<?php echo $user_data['first_name'].' '.$user_data['last_name']; ?>">
                          <input type="hidden" name="course_title"    value="<?php echo $course_data['title']; ?>">
                          <input type="hidden" name="public_live_key" value="<?php echo $stripe_keys[0]['public_live_key']; ?>">
                          <input type="hidden" name="secret_live_key" value="<?php echo $stripe_keys[0]['secret_live_key']; ?>">
                          <input type="submit" class="btn btn-outline-info btn-sm btn-rounded"   value="<?php echo get_phrase('pay_with_stripe'); ?>">
                        </form>
                      <?php else: ?>
                        <button type="button" class = "btn btn-outline-danger btn-sm btn-rounded" name="button" onclick="alert('<?php echo get_phrase('this_instructor_has_not_provided_valid_public_key_or_secret_key'); ?>')"><?php echo get_phrase('pay_with_stripe'); ?></button>
                      <?php endif; ?>-->


                    <?php if ($user_data['cashfree_app'] != "" && $user_data['cashfree_secret'] !=""): ?>
					<form method="post" action="<?php echo site_url('admin/cashfree_checkout_for_instructor_revenue'); ?>">
                          <input type="hidden" class="form-control" name="appId" value="<?php echo $user_data['cashfree_app']; ?>">
                          <input type="hidden" class="form-control" name="orderId" value="<?php echo  "TN" . rand(10000,99999999) . $user_data['id'] ?>">
                          <input type="hidden" class="form-control" name="orderAmount" value="<?php echo $payment['instructor_revenue']; ?>">
                          <input type="hidden" class="form-control" name="orderCurrency" value="INR">
		                      <input type="hidden" class="form-control" name="orderNote" value="">
		                      <input type="hidden" class="form-control" name="customerName" value="">
                          <input type="hidden" class="form-control" name="customerEmail" value="<?php echo $user_details['email']; ?>">
                          <input type="hidden" class="form-control" name="customerPhone" value="9999999999">
                          <input type="hidden" class="form-control" name="returnUrl" value="<?php echo site_url('admin/cashfree_payment/' . $payment['id']); ?>">
                          <input type="hidden" class="form-control" name="notifyUrl" value="">
                          <input type="submit" class="btn btn-outline-info btn-sm btn-rounded" value="<?php echo get_phrase('pay_with_cashfree'); ?>">
          </form>
					<?php else: ?>
                        <button type="button" class = "btn btn-outline-danger btn-sm btn-rounded" name="button" onclick="alert('<?php echo get_phrase('this_instructor_has_not_provided_valid_app_id_or_secret_key'); ?>')"><?php echo get_phrase('pay_with_cashfree'); ?></button>
                    <?php endif; ?>

                    <?php else: ?>
                      <a href="<?php echo site_url('admin/invoice/'.$payment['id']); ?>" class="btn btn-outline-primary btn-rounded btn-sm"><i class="mdi mdi-printer-settings"></i></a>
                    <?php endif; ?>


                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
