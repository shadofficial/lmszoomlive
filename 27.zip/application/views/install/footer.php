<footer class="main"
	style="text-align: center;">
	Need help? Contact support!
</footer>
