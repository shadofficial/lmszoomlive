<?php $secretKey = $this->db->get_where('settings', array('key' => 'cashfree_app'))->row()->value; ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Cashfree-PG TestForm</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="icon" href="<?php echo base_url('assets/payment/cashfree_favicon.png'); ?>" type="image/png" sizes="16x16">
  </head>
  <body>
    <div class="container fluid">
      <form id="redirectForm" method="post" action="<?php echo site_url('home/request'); ?>">
          <input type="hidden" class="form-control" name="appId" value="<?php echo $secretKey; ?>" />
          <input type="hidden" class="form-control" name="orderId" value="<?php echo  "TN" . rand(10000,99999999) . $user_details['id'] ?>" />
          <input type="hidden" class="form-control" name="orderAmount" value="<?php echo $amount_to_pay; ?>" />
          <input type="hidden" class="form-control" name="orderCurrency" value="INR" />
		  <input type="hidden" class="form-control" name="orderNote" value="" />
		  <input type="hidden" class="form-control" name="customerName" value="" />
          <input type="hidden" class="form-control" name="customerEmail" value="<?php echo $user_details['email']; ?>" />
          <input type="hidden" class="form-control" name="customerPhone" value="<?php echo $_POST["customerPhone"]; ?>" />
          <input type="hidden" class="form-control" name="returnUrl" value="<?php echo site_url('home/response'); ?>" />
          <input type="hidden" class="form-control" name="notifyUrl" value="" />
      </form>
    </div>    
  </body>
</html>
<script>document.getElementById("redirectForm").submit();</script>